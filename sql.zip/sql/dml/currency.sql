INSERT INTO currency (code, rate, symbol, locale, noun, adjective) 
VALUES
('EUR', 1, '€', 'en', 'England', 'english'),
('PLN', 4.2302, 'zł', 'pl', 'Polska', 'polski'),
('RUB', 47.437, 'руб', 'ru', 'Россия', 'русский');
