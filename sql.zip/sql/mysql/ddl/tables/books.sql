CREATE TABLE books
(
	id integer NOT NULL AUTO_INCREMENT,
	title varcharacter(80) NOT NULL,
	volume integer,
	edition integer,
	place_of_publication varcharacter(10) NOT NULL,
	year_of_publication integer NOT NULL,
	PRIMARY KEY (id)
);
