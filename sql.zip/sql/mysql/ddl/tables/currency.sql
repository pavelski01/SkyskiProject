CREATE TABLE currency
(
	id integer NOT NULL AUTO_INCREMENT,
	code character(3),
	rate double,
	symbol varcharacter(10),
	locale varcharacter(10),
	noun varcharacter(30),
	adjective varcharacter(30),
	CONSTRAINT currency_pkey PRIMARY KEY (id),
	CONSTRAINT currency_code_currency_key UNIQUE (code)
);
