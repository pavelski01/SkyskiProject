CREATE TABLE merchandise
(
	id integer NOT NULL AUTO_INCREMENT,
	name varcharacter(50),
	countable boolean,
	amount double,
	price double,
	PRIMARY KEY (id),
	CONSTRAINT merchandise_name_merchandise_key UNIQUE (name)
);
