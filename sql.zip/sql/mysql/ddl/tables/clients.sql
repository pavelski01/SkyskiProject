CREATE TABLE clients
(
	id integer NOT NULL AUTO_INCREMENT,
	login varcharacter(20) NOT NULL,
	passwd varcharacter(20) NOT NULL,
	email varcharacter(20) NOT NULL,
	forename varcharacter(20),
	surname varcharacter(30),
	street varcharacter(20),
	postal_code varcharacter(10),
	city varcharacter(20),
	date_of_birth date,
	confirmed boolean,
	phone varcharacter(20),
	PRIMARY KEY (id),
	CONSTRAINT clients_email_clients_key UNIQUE (email),
	CONSTRAINT clients_login_clients_key UNIQUE (login)
);
