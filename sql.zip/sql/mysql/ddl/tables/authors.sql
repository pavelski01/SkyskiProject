CREATE TABLE authors
(
	id integer NOT NULL AUTO_INCREMENT,
	surname varcharacter(20) NOT NULL,
	forename varcharacter(10) NOT NULL,
	PRIMARY KEY (id)
);
