CREATE TABLE merchandise_ru
(
	id integer NOT NULL AUTO_INCREMENT,
	name varcharacter(50),
	PRIMARY KEY (id),
	CONSTRAINT merchandise_ru_id_fkey FOREIGN KEY (id) 
		REFERENCES merchandise (id) MATCH SIMPLE 
			ON UPDATE NO ACTION ON DELETE NO ACTION,
	CONSTRAINT merchandise_ru_name_key UNIQUE (name)
);
